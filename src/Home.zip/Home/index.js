import React from 'react';
import HeroSection from './heroSection';
import PersonalizedContent from './personalizedSection';
import PressSection from './pressSection';
import ContentSection from './contentSection';
import ChoiceSection from './choiceSection';
import TestimonialSection from './testimonialSection';
import PricingSection from './pricingSection';

function Home() {
  const isLoggedIn = true;

  return (
    <div>
      <HeroSection />
      {isLoggedIn && <PersonalizedContent />}
      <ContentSection />
      <ChoiceSection />
      <TestimonialSection />
      <PressSection/>
      {!isLoggedIn && <PricingSection />}
    </div>
  );
}

export default Home;
