import React from 'react';
import './test.css'; 
import profile from "../../images/profile.jpg";
function TestimonialSection() {
  return (
    <section id="testimonials">
        <div id="carouselExampleControls" className="carousel slide" data-ride="false">
            <div className="carousel-inner">
                <div className="carousel-item active">
                    <h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis ligula vitae tincidunt iaculis.</h2>
                    <img className="test-img" src={profile} alt="profile"/>
                    <em>Pebbles, New York</em>
                </div>
                <div className="carousel-item">
                    <h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis ligula vitae tincidunt iaculis.</h2>
                    <img className="testimonial-image" src={profile} alt="profile"/>
                    <em>Beverly, Illinois</em>
                </div>
            </div>
            <a className="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                <span className="sr-only">Previous</span>
            </a>
            <a className="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                <span className="sr-only">Next</span>
            </a>
        </div>
    </section>
  );
}

export default TestimonialSection;
