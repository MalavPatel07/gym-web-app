import React from 'react';
import feature1 from "../../images/feature-1.jpg";
import feature2 from "../../images/feature-2.jpg";
import feature3 from "../../images/feature-3.jpg";
import feature4 from "../../images/feature-4.jpg";

function ChoiceSection() {
  return (
    <section id="choice">
    <div className="container feature pt-5">
        <div className="d-flex flex-column text-center mb-5">
            <h4 className="font-weight-bold red-highlight">Why Choose Us?</h4>
            <h4 className="display-4 font-weight-bold">Benifits of Joining Our GYM</h4>
        </div>
        <div className="row">
            <div className="col-md-6 mb-5">
                <div className="row align-items-center">
                    <div className="col-sm-5">
                        <img className="img-fluid mb-3 mb-sm-0" src={feature1} alt="feature1"/>
                    </div>
                    <div className="col-sm-7">
                        <h4 className="font-weight-bold">Videos Instruction</h4>
                        <p>Sit lorem ipsum et diam elitr est dolor sed duo. Guberg sea et et lorem dolor sed est sit invidunt, dolore tempor diam ipsum takima erat tempor</p>
                    </div>
                </div>
            </div>
            <div className="col-md-6 mb-5">
                <div className="row align-items-center">
                    <div className="col-sm-5">
                        <img className="img-fluid mb-3 mb-sm-0" src={feature2} alt="feature2"/>
                    </div>
                    <div className="col-sm-7">
                        <h4 className="font-weight-bold">Training Calendar</h4>
                        <p>Sit lorem ipsum et diam elitr est dolor sed duo. Guberg sea et et lorem dolor sed est sit invidunt, dolore tempor diam ipsum takima erat tempor</p>
                    </div>
                </div>
            </div>
            <div className="col-md-6 mb-5">
                <div className="row align-items-center">
                    <div className="col-sm-5">
                        <img className="img-fluid mb-3 mb-sm-0" src={feature3} alt="feature3"/>
                    </div>
                    <div className="col-sm-7">
                        <h4 className="font-weight-bold">Free Apps & WiFi</h4>
                        <p>Sit lorem ipsum et diam elitr est dolor sed duo. Guberg sea et et lorem dolor sed est sit invidunt, dolore tempor diam ipsum takima erat tempor</p>
                    </div>
                </div>
            </div>
            <div className="col-md-6 mb-5">
                <div className="row align-items-center">
                    <div className="col-sm-5">
                        <img className="img-fluid mb-3 mb-sm-0" src={feature4} alt="feature4"/>
                    </div>
                    <div className="col-sm-7">
                        <h4 className="font-weight-bold">Community Support</h4>
                        <p>Sit lorem ipsum et diam elitr est dolor sed duo. Guberg sea et et lorem dolor sed est sit invidunt, dolore tempor diam ipsum takima erat tempor</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>  );
}

export default ChoiceSection;
