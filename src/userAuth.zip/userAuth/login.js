import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios'; 

export default function Login({ setLoggedIn }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/login', { email, password });
      if (response.data.success) {
        setLoggedIn(true);
        navigate.push('/'); 
      } else {
        alert('Login failed!');
      }
    } catch (error) {
      console.error('Login error', error);
    }
  };

  return (
    <div className="container d-flex align-items-center justify-content-center" style={{ minHeight: 100 }}>
      <div className="card shadow" style={{ width: 400}}>
        <div className="card-body p-5">
          <h2 className="card-title text-center mb-4">Sign In</h2>
          <form onSubmit={handleLogin}>
            <div className="mb-3">
              <input type="email" className="form-control" id="email" placeholder="Email address" required autoFocus onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="mb-3">
              <input type="password" className="form-control" id="password" placeholder="Password" required onChange={(e) => setPassword(e.target.value)} />
            </div>
            <div className="d-grid mb-2">
              <button className="btn btn-lg btn-outline-danger btn-block" type="submit">Sign In</button>
            </div>
          </form>
          <a href="#" className="text-muted text-center d-block">Forgot Password?</a>
        </div>
      </div>
    </div>
  );
}
